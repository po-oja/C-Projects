create database library_db

use library_db

create table books(
bookid int identity(100,1),
bookname varchar(100) not null,
authorname varchar(100) not null,
bookimage varchar(100) not null,
bookaddeddate datetime not null)

create table students(
studentid int identity(1000,1),
studentname varchar(100) not null,
studentemail varchar(100) not null,
studentDOB datetime not null,
studentpassword varchar(100) not null,
studentgender varchar(100) not null,
studentimage varchar(100)not null)


alter proc proc_addstudent(@name varchar(100),@email varchar(100),@DOB datetime,@password varchar(100),@gender varchar(100),@image varchar(100))
as
begin
 insert students values(@name,@email,@DOB,@password,@gender,@image);
	 return @@identity
	 end



alter proc proc_login(@id int ,@password varchar(100))
		as
		begin
		declare @count int=0
        select @count=count(*) from students
		where studentid=@id and  studentpassword=@password
		return @count
		end  


create proc proc_findstudent(@id int )
as
begin
select * from students where studentid=@id;
end

alter proc proc_addbook(@name varchar(100),@author varchar(100),@bimage varchar(100))
as
begin
insert into books values(@name,@author,@bimage,getdate());
return @@identity
end

create proc proc_searchbook(@key varchar(100))
as
begin
select * from books where bookid ='%'+@key+'%' or bookname='%'+@key+'%' or authorname='%'+@key+'%'
end