﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Win_banking_ado
{
    class accountModel
    {
        public int accountid { get; set; }
        public int  customerID { get; set; }
        public string accounttype { get; set; }
        public int accountbalance { get; set; }
        public DateTime accountdate { get; set; }


    }
}
