﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_banking_ado
{
    public partial class Frm_new_transaction : Form
    {
        public Frm_new_transaction()
        {
            InitializeComponent();
        }

        private void btn_addtrans_Click(object sender, EventArgs e)
        { 
            /*
            if (txt_accid.Text == string.Empty)
            {
                lbl_status.Text = "enter accountID";
            }
            else if (txt_transtype.Text == string.Empty)
            {
                lbl_status.Text = "enter transaction type";
            }
            else if (txt_amount.Text == string.Empty)
            {
                lbl_status.Text = "enter amount";
            }

            else if (dtp_transdate.Text == string.Empty)
            {
                lbl_status.Text = "select the date";
            }*/

            
            
                transactionModel model = new transactionModel();
            model.accountid = Convert.ToInt32(ddl_accounts.Text);
                model.transactiontype=txt_transtype.Text;
                model.amount = Convert.ToInt32(txt_amount.Text);
                model.transactiondate = Convert.ToDateTime(dtp_transdate.Value);

                bankingDAL dal2 = new bankingDAL();
                int id = dal2.addtransaction(model);
               lbl_status.Text = "transaction added,ID" + id;

            bankingDAL.AID = model.accountid;

        }

        private void Frm_new_transaction_Load(object sender, EventArgs e)
        {
            bankingDAL obj = new bankingDAL();
            List<accountModel> list = obj.find(bankingDAL.ID);
            foreach(accountModel a in list)
            {
                ddl_accounts.Items.Add(a.accountid);
            }
        }
    }
}
