﻿namespace Win_banking_ado
{
    partial class Frm_new_transaction
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_addtrans = new System.Windows.Forms.Button();
            this.dtp_transdate = new System.Windows.Forms.DateTimePicker();
            this.lbl_transdate = new System.Windows.Forms.Label();
            this.txt_amount = new System.Windows.Forms.TextBox();
            this.txt_transtype = new System.Windows.Forms.TextBox();
            this.lbl_balance = new System.Windows.Forms.Label();
            this.lbl_accounttype = new System.Windows.Forms.Label();
            this.lbl_idacc = new System.Windows.Forms.Label();
            this.ddl_accounts = new System.Windows.Forms.ComboBox();
            this.lbl_status = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_addtrans
            // 
            this.btn_addtrans.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_addtrans.Location = new System.Drawing.Point(348, 239);
            this.btn_addtrans.Name = "btn_addtrans";
            this.btn_addtrans.Size = new System.Drawing.Size(192, 39);
            this.btn_addtrans.TabIndex = 46;
            this.btn_addtrans.Text = "Add Transaction";
            this.btn_addtrans.UseVisualStyleBackColor = true;
            this.btn_addtrans.Click += new System.EventHandler(this.btn_addtrans_Click);
            // 
            // dtp_transdate
            // 
            this.dtp_transdate.CustomFormat = "MM-dd-yyyy";
            this.dtp_transdate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtp_transdate.Location = new System.Drawing.Point(427, 194);
            this.dtp_transdate.Name = "dtp_transdate";
            this.dtp_transdate.Size = new System.Drawing.Size(200, 20);
            this.dtp_transdate.TabIndex = 45;
            // 
            // lbl_transdate
            // 
            this.lbl_transdate.AutoSize = true;
            this.lbl_transdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_transdate.Location = new System.Drawing.Point(237, 190);
            this.lbl_transdate.Name = "lbl_transdate";
            this.lbl_transdate.Size = new System.Drawing.Size(156, 24);
            this.lbl_transdate.TabIndex = 44;
            this.lbl_transdate.Text = "Transaction Date ";
            // 
            // txt_amount
            // 
            this.txt_amount.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_amount.Location = new System.Drawing.Point(439, 142);
            this.txt_amount.Name = "txt_amount";
            this.txt_amount.Size = new System.Drawing.Size(122, 29);
            this.txt_amount.TabIndex = 43;
            // 
            // txt_transtype
            // 
            this.txt_transtype.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_transtype.Location = new System.Drawing.Point(439, 87);
            this.txt_transtype.Name = "txt_transtype";
            this.txt_transtype.Size = new System.Drawing.Size(122, 29);
            this.txt_transtype.TabIndex = 42;
            // 
            // lbl_balance
            // 
            this.lbl_balance.AutoSize = true;
            this.lbl_balance.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_balance.Location = new System.Drawing.Point(304, 145);
            this.lbl_balance.Name = "lbl_balance";
            this.lbl_balance.Size = new System.Drawing.Size(76, 24);
            this.lbl_balance.TabIndex = 40;
            this.lbl_balance.Text = "Amount";
            // 
            // lbl_accounttype
            // 
            this.lbl_accounttype.AutoSize = true;
            this.lbl_accounttype.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_accounttype.Location = new System.Drawing.Point(252, 87);
            this.lbl_accounttype.Name = "lbl_accounttype";
            this.lbl_accounttype.Size = new System.Drawing.Size(156, 24);
            this.lbl_accounttype.TabIndex = 39;
            this.lbl_accounttype.Text = "Transaction Type";
            // 
            // lbl_idacc
            // 
            this.lbl_idacc.AutoSize = true;
            this.lbl_idacc.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_idacc.Location = new System.Drawing.Point(249, 45);
            this.lbl_idacc.Name = "lbl_idacc";
            this.lbl_idacc.Size = new System.Drawing.Size(102, 24);
            this.lbl_idacc.TabIndex = 38;
            this.lbl_idacc.Text = "Account ID";
            // 
            // ddl_accounts
            // 
            this.ddl_accounts.FormattingEnabled = true;
            this.ddl_accounts.Location = new System.Drawing.Point(439, 45);
            this.ddl_accounts.Name = "ddl_accounts";
            this.ddl_accounts.Size = new System.Drawing.Size(130, 21);
            this.ddl_accounts.TabIndex = 47;
            // 
            // lbl_status
            // 
            this.lbl_status.AutoSize = true;
            this.lbl_status.Location = new System.Drawing.Point(253, 316);
            this.lbl_status.Name = "lbl_status";
            this.lbl_status.Size = new System.Drawing.Size(96, 13);
            this.lbl_status.TabIndex = 48;
            this.lbl_status.Text = "transaction status :";
            // 
            // Frm_new_transaction
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(834, 384);
            this.Controls.Add(this.lbl_status);
            this.Controls.Add(this.ddl_accounts);
            this.Controls.Add(this.btn_addtrans);
            this.Controls.Add(this.dtp_transdate);
            this.Controls.Add(this.lbl_transdate);
            this.Controls.Add(this.txt_amount);
            this.Controls.Add(this.txt_transtype);
            this.Controls.Add(this.lbl_balance);
            this.Controls.Add(this.lbl_accounttype);
            this.Controls.Add(this.lbl_idacc);
            this.Name = "Frm_new_transaction";
            this.Text = "Frm_new_transaction";
            this.Load += new System.EventHandler(this.Frm_new_transaction_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btn_addtrans;
        private System.Windows.Forms.DateTimePicker dtp_transdate;
        private System.Windows.Forms.Label lbl_transdate;
        private System.Windows.Forms.TextBox txt_amount;
        private System.Windows.Forms.TextBox txt_transtype;
        private System.Windows.Forms.Label lbl_balance;
        private System.Windows.Forms.Label lbl_accounttype;
        private System.Windows.Forms.Label lbl_idacc;
        private System.Windows.Forms.ComboBox ddl_accounts;
        private System.Windows.Forms.Label lbl_status;
    }
}