﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_banking_ado
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void lbl_login_Click(object sender, EventArgs e)
        {

        }

        private void txt_password_TextChanged(object sender, EventArgs e)
        {

        }

        private void splitter1_SplitterMoved(object sender, SplitterEventArgs e)
        {

        }

        private void lbl_log_Click(object sender, EventArgs e)
        {

        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            if (txt_login.Text == string.Empty)
            {
                lbl_loginstatus.Text = "enter login ID";

            }
            else if (txt_password.Text == string.Empty)
            {
                lbl_loginstatus.Text = "enter password";
            }
            else
            {
                try
                {
                    int loginid = Convert.ToInt32(txt_login.Text);
                    string password = txt_password.Text;
                    bankingDAL dal = new bankingDAL();
                   bool status = dal.login(loginid, password);
                    if (status == true)
                    {
                        bankingDAL.ID = loginid;
                        Frm_home obj1 = new Frm_home();
                        obj1.Show();
                    }
                    else
                    {
                        lbl_loginstatus.Text = "inavlid user ID and password";
                    }
                }
                catch (Exception exp)
                {

                    MessageBox.Show(exp.Message);
                }
            }

        }
             private void btn_newuser_Click(object sender, EventArgs e)
        {
        }
        private void btn_newuser_Click_1(object sender, EventArgs e)
        {
            if (txt_custname.Text == string.Empty)
            {
                lbl_custid.Text = "enter valid name";
            }
            else if (txt_email.Text == string.Empty)
            {
                lbl_custid.Text = "enter the email";
            }

            else if (txt_custpassword.Text == string.Empty)
            {
                lbl_custid.Text = "enter password";
            }
           
            else if (txt_mobile.Text == string.Empty)
            {
                lbl_custid.Text = "enter mobile number";
            }
            else if (rdb_male.Checked == false && rdb_female.Checked == false)
            {
                MessageBox.Show("select gender");
            }

            else
            {
                customerModel model = new customerModel();
                model.customername = txt_custname.Text;
                model.customeremail = txt_email.Text;
                model.customerpassword = txt_custpassword.Text;
                model.customermobile = txt_mobile.Text;
                model.customergender = string.Empty;
                if (rdb_male.Checked == true)
                {
                    model.customergender= "male";
                }
                else
                {
                    model.customergender = "female";
                }

                bankingDAL dal = new bankingDAL();
                int id = dal.addcustomer(model);
                lbl_custid.Text = "customer added,ID" + id;
            }


        }

    
      }
    }

