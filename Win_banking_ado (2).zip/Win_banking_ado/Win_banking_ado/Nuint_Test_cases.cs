﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;

namespace Win_banking_ado
{
    class Nuint_Test_cases
    {
        [Test]
        public void testvalidlogin()
        {
            bankingDAL dal = new bankingDAL();
            bool status = dal.login(1000,"pooja@gmail");
            Assert.AreEqual(status, true);

        }
        [Test]
        public void testinvalidlogin()
        {
            bankingDAL dal = new bankingDAL();
            bool status = dal.login(1003,"126777");
            Assert.AreEqual(status,false);
        }
        
        [Test]
        public void testaddcustomer()
        {
            customerModel m = new customerModel();
            m.customername = "abc";
            m.customeremail = "abc@gmail";
            m.customerpassword = "1234";
            m.customermobile = "38265727385";
            m.customergender = "female";
            bankingDAL dal = new bankingDAL();
            int id = dal.addcustomer(m);
            Assert.Greater(id, 0);
        }

        /*
        [Test]
        public void testaddinvalidcustomer()
        {
            customerModel m = new customerModel();
            m.customername = "abc";
            m.customeremail = "abc@gmail";
            m.customerpassword = "1234";
            m.customermobile = null;
            m.customergender = "female";
            bankingDAL dal = new bankingDAL();
            int id = dal.addcustomer(m);
            Assert.NotNull(m.customermobile);
        }*/
        


       /* [Test]
        [TestCase(1000)]
        public void Testfind(int id)
        {
            bankingDAL dal = new bankingDAL();
             accountModel model = dal.find(id);
            Assert.NotNull(model);
        }
        */
       // [Test]

      /*  [TestCase(0)]
        public void Testinvalidfind(int id)
        {
            bankingDAL dal = new bankingDAL();
            accountModel model = dal.find(id);
            Assert.Null(model);
        }*/





    }
}
