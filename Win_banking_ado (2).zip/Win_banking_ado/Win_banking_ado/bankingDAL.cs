﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;


namespace Win_banking_ado
{
    class bankingDAL
    {

        public static int ID;
        public static int AID;
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);

        public int addcustomer(customerModel model)
        {
            try
            {
                SqlCommand com_addcustomer = new SqlCommand("proc_addcustomer", con);
                com_addcustomer.CommandType = CommandType.StoredProcedure;
                com_addcustomer.Parameters.AddWithValue("@name", model.customername);
                com_addcustomer.Parameters.AddWithValue("@email", model.customeremail);
                com_addcustomer.Parameters.AddWithValue("@password", model.customerpassword);
                com_addcustomer.Parameters.AddWithValue("@mobile", model.customermobile);
                com_addcustomer.Parameters.AddWithValue("@gender", model.customergender);
                SqlParameter para_return = new SqlParameter();
                para_return.Direction = ParameterDirection.ReturnValue;
                com_addcustomer.Parameters.Add(para_return);
                con.Open();
                com_addcustomer.ExecuteNonQuery();
                con.Close();
                int id = Convert.ToInt32(para_return.Value);
                return id;

            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }


             public bool login(int id, string password)
        {
            try
            {
                SqlCommand com_login = new SqlCommand("proc_login", con);
                com_login.CommandType = CommandType.StoredProcedure;
                com_login.Parameters.AddWithValue("@id", id);
                com_login.Parameters.AddWithValue("@password", password);
                SqlParameter para_return = new SqlParameter();
                para_return.Direction = ParameterDirection.ReturnValue;
                com_login.Parameters.Add(para_return);
                con.Open();
                com_login.ExecuteNonQuery();
                con.Close();
                int count = Convert.ToInt32(para_return.Value);
                if (count > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            finally
            {
                
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }

            }
        }

        public int addaccount(accountModel model)
        {
            try
            {
                SqlCommand com_addaccount = new SqlCommand("proc_addaccount", con);
                com_addaccount.CommandType = CommandType.StoredProcedure;
                com_addaccount.Parameters.AddWithValue("@customerID", model.customerID);
                com_addaccount.Parameters.AddWithValue("@accounttype", model.accounttype);
                com_addaccount.Parameters.AddWithValue("@balance", model.accountbalance);
                com_addaccount.Parameters.AddWithValue("@accountdate", model.accountdate);
                SqlParameter para_return = new SqlParameter();
                para_return.Direction = ParameterDirection.ReturnValue;
                com_addaccount.Parameters.Add(para_return);
                con.Open();
                com_addaccount.ExecuteNonQuery();
                con.Close();
                int id = Convert.ToInt32(para_return.Value);
                return id;

            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }

        public List<accountModel> find(int id)
        {
            try
            {
                SqlCommand com_find = new SqlCommand("proc_searchaccount", con);
                com_find.CommandType = CommandType.StoredProcedure;
                com_find.Parameters.AddWithValue("@cid", id);
                con.Open();
                SqlDataReader dr = com_find.ExecuteReader();
                List<accountModel> cutlist = new List<accountModel>();
                while (dr.Read())
                {
                    accountModel model = new accountModel();
                    model.accountid = dr.GetInt32(0);
                    model.customerID = dr.GetInt32(1);
                    model.accounttype = dr.GetString(2);
                    model.accountbalance = dr.GetInt32(3);
                    model.accountdate = dr.GetDateTime(4);
                    cutlist.Add(model);
                }

                    con.Close();
                    return cutlist;
                
               // con.Close();
               // return null;
            }
            finally
            {

                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }

            }
        }

        public int addtransaction(transactionModel model)
        {
            try
            {
                SqlCommand com_addaccount = new SqlCommand("proc_addtransaction", con);
                com_addaccount.CommandType = CommandType.StoredProcedure;
                com_addaccount.Parameters.AddWithValue("@accountid", model.accountid);
                com_addaccount.Parameters.AddWithValue("@transactiontype", model.transactiontype);
                com_addaccount.Parameters.AddWithValue("@amount", model.amount);
                com_addaccount.Parameters.AddWithValue("@transaction", model.transactiondate);
                SqlParameter para_return = new SqlParameter();
                para_return.Direction = ParameterDirection.ReturnValue;
                com_addaccount.Parameters.Add(para_return);
                con.Open();
                com_addaccount.ExecuteNonQuery();
                con.Close();
                int id = Convert.ToInt32(para_return.Value);
                return id;

            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }

        public List<transactionModel> search(int id)
        {
            try
            {
                SqlCommand com_find = new SqlCommand("proc_searchtransaction", con);
                com_find.CommandType = CommandType.StoredProcedure;
                com_find.Parameters.AddWithValue("@aid", id);
                con.Open();
                SqlDataReader dr = com_find.ExecuteReader();
                List<transactionModel> custlist = new List<transactionModel>();
                while (dr.Read())
                {
                    transactionModel model = new transactionModel();
                    model.accountid = dr.GetInt32(0);
                    model.transactionid = dr.GetInt32(1);
                    model.amount = dr.GetInt32(2);
                    model.transactiontype = dr.GetString(3);
                    model.transactiondate = dr.GetDateTime(4);
                     
                    custlist.Add(model);
                    
                }
                con.Close();
                return custlist;
                con.Close();
                return null;
            }
            finally
            {

                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }

            }
        }













    }
}

