﻿namespace Win_banking_ado
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_loginstatus = new System.Windows.Forms.Label();
            this.btn_newuser = new System.Windows.Forms.Button();
            this.btn_login = new System.Windows.Forms.Button();
            this.txt_password = new System.Windows.Forms.TextBox();
            this.txt_login = new System.Windows.Forms.TextBox();
            this.lbl_password = new System.Windows.Forms.Label();
            this.lbl_login = new System.Windows.Forms.Label();
            this.txt_email = new System.Windows.Forms.TextBox();
            this.lbl_email = new System.Windows.Forms.Label();
            this.txt_mobile = new System.Windows.Forms.TextBox();
            this.lbl_mobile = new System.Windows.Forms.Label();
            this.lbl_custid = new System.Windows.Forms.Label();
            this.txt_custname = new System.Windows.Forms.TextBox();
            this.lbl_name = new System.Windows.Forms.Label();
            this.lbl_gender = new System.Windows.Forms.Label();
            this.lbl_log = new System.Windows.Forms.Label();
            this.lbl_newuser = new System.Windows.Forms.Label();
            this.txt_custpassword = new System.Windows.Forms.TextBox();
            this.lbl_pass = new System.Windows.Forms.Label();
            this.rdb_male = new System.Windows.Forms.RadioButton();
            this.rdb_female = new System.Windows.Forms.RadioButton();
            this.SuspendLayout();
            // 
            // lbl_loginstatus
            // 
            this.lbl_loginstatus.AutoSize = true;
            this.lbl_loginstatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_loginstatus.Location = new System.Drawing.Point(14, 251);
            this.lbl_loginstatus.Name = "lbl_loginstatus";
            this.lbl_loginstatus.Size = new System.Drawing.Size(122, 24);
            this.lbl_loginstatus.TabIndex = 20;
            this.lbl_loginstatus.Text = "Login Status :";
            // 
            // btn_newuser
            // 
            this.btn_newuser.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_newuser.ForeColor = System.Drawing.Color.SaddleBrown;
            this.btn_newuser.Location = new System.Drawing.Point(542, 326);
            this.btn_newuser.Name = "btn_newuser";
            this.btn_newuser.Size = new System.Drawing.Size(109, 40);
            this.btn_newuser.TabIndex = 19;
            this.btn_newuser.Text = "New User";
            this.btn_newuser.UseVisualStyleBackColor = true;
            this.btn_newuser.Click += new System.EventHandler(this.btn_newuser_Click_1);
            // 
            // btn_login
            // 
            this.btn_login.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_login.ForeColor = System.Drawing.Color.SaddleBrown;
            this.btn_login.Location = new System.Drawing.Point(138, 192);
            this.btn_login.Name = "btn_login";
            this.btn_login.Size = new System.Drawing.Size(109, 40);
            this.btn_login.TabIndex = 18;
            this.btn_login.Text = "Login";
            this.btn_login.UseVisualStyleBackColor = true;
            this.btn_login.Click += new System.EventHandler(this.btn_login_Click);
            // 
            // txt_password
            // 
            this.txt_password.BackColor = System.Drawing.Color.Salmon;
            this.txt_password.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_password.Location = new System.Drawing.Point(166, 120);
            this.txt_password.Name = "txt_password";
            this.txt_password.PasswordChar = '*';
            this.txt_password.Size = new System.Drawing.Size(134, 29);
            this.txt_password.TabIndex = 17;
            this.txt_password.TextChanged += new System.EventHandler(this.txt_password_TextChanged);
            // 
            // txt_login
            // 
            this.txt_login.BackColor = System.Drawing.Color.Salmon;
            this.txt_login.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_login.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txt_login.Location = new System.Drawing.Point(166, 62);
            this.txt_login.Name = "txt_login";
            this.txt_login.Size = new System.Drawing.Size(134, 29);
            this.txt_login.TabIndex = 16;
            // 
            // lbl_password
            // 
            this.lbl_password.AutoSize = true;
            this.lbl_password.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_password.Location = new System.Drawing.Point(38, 120);
            this.lbl_password.Name = "lbl_password";
            this.lbl_password.Size = new System.Drawing.Size(92, 24);
            this.lbl_password.TabIndex = 15;
            this.lbl_password.Text = "Password";
            // 
            // lbl_login
            // 
            this.lbl_login.AutoSize = true;
            this.lbl_login.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_login.Location = new System.Drawing.Point(38, 62);
            this.lbl_login.Name = "lbl_login";
            this.lbl_login.Size = new System.Drawing.Size(79, 24);
            this.lbl_login.TabIndex = 14;
            this.lbl_login.Text = "Login ID";
            this.lbl_login.Click += new System.EventHandler(this.lbl_login_Click);
            // 
            // txt_email
            // 
            this.txt_email.BackColor = System.Drawing.SystemColors.HotTrack;
            this.txt_email.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_email.Location = new System.Drawing.Point(579, 106);
            this.txt_email.Name = "txt_email";
            this.txt_email.Size = new System.Drawing.Size(147, 29);
            this.txt_email.TabIndex = 38;
            // 
            // lbl_email
            // 
            this.lbl_email.AutoSize = true;
            this.lbl_email.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_email.Location = new System.Drawing.Point(382, 111);
            this.lbl_email.Name = "lbl_email";
            this.lbl_email.Size = new System.Drawing.Size(138, 24);
            this.lbl_email.TabIndex = 37;
            this.lbl_email.Text = "customer email";
            // 
            // txt_mobile
            // 
            this.txt_mobile.BackColor = System.Drawing.SystemColors.HotTrack;
            this.txt_mobile.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_mobile.Location = new System.Drawing.Point(579, 203);
            this.txt_mobile.Name = "txt_mobile";
            this.txt_mobile.Size = new System.Drawing.Size(147, 29);
            this.txt_mobile.TabIndex = 36;
            // 
            // lbl_mobile
            // 
            this.lbl_mobile.AutoSize = true;
            this.lbl_mobile.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_mobile.Location = new System.Drawing.Point(382, 208);
            this.lbl_mobile.Name = "lbl_mobile";
            this.lbl_mobile.Size = new System.Drawing.Size(150, 24);
            this.lbl_mobile.TabIndex = 35;
            this.lbl_mobile.Text = "customer mobile";
            // 
            // lbl_custid
            // 
            this.lbl_custid.AutoSize = true;
            this.lbl_custid.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_custid.Location = new System.Drawing.Point(408, 393);
            this.lbl_custid.Name = "lbl_custid";
            this.lbl_custid.Size = new System.Drawing.Size(123, 24);
            this.lbl_custid.TabIndex = 34;
            this.lbl_custid.Text = "Customer ID :";
            // 
            // txt_custname
            // 
            this.txt_custname.BackColor = System.Drawing.SystemColors.HotTrack;
            this.txt_custname.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_custname.Location = new System.Drawing.Point(581, 71);
            this.txt_custname.Name = "txt_custname";
            this.txt_custname.Size = new System.Drawing.Size(147, 29);
            this.txt_custname.TabIndex = 29;
            // 
            // lbl_name
            // 
            this.lbl_name.AutoSize = true;
            this.lbl_name.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_name.Location = new System.Drawing.Point(382, 71);
            this.lbl_name.Name = "lbl_name";
            this.lbl_name.Size = new System.Drawing.Size(144, 24);
            this.lbl_name.TabIndex = 25;
            this.lbl_name.Text = "customer Name";
            // 
            // lbl_gender
            // 
            this.lbl_gender.AutoSize = true;
            this.lbl_gender.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_gender.Location = new System.Drawing.Point(382, 253);
            this.lbl_gender.Name = "lbl_gender";
            this.lbl_gender.Size = new System.Drawing.Size(157, 24);
            this.lbl_gender.TabIndex = 39;
            this.lbl_gender.Text = "customer Gender";
            // 
            // lbl_log
            // 
            this.lbl_log.AutoSize = true;
            this.lbl_log.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_log.ForeColor = System.Drawing.Color.DarkGreen;
            this.lbl_log.Location = new System.Drawing.Point(162, 23);
            this.lbl_log.Name = "lbl_log";
            this.lbl_log.Size = new System.Drawing.Size(88, 25);
            this.lbl_log.TabIndex = 41;
            this.lbl_log.Text = "LOGIN ";
            this.lbl_log.Click += new System.EventHandler(this.lbl_log_Click);
            // 
            // lbl_newuser
            // 
            this.lbl_newuser.AutoSize = true;
            this.lbl_newuser.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_newuser.ForeColor = System.Drawing.Color.DarkGreen;
            this.lbl_newuser.Location = new System.Drawing.Point(581, 23);
            this.lbl_newuser.Name = "lbl_newuser";
            this.lbl_newuser.Size = new System.Drawing.Size(100, 25);
            this.lbl_newuser.TabIndex = 42;
            this.lbl_newuser.Text = "Register";
            // 
            // txt_custpassword
            // 
            this.txt_custpassword.BackColor = System.Drawing.SystemColors.HotTrack;
            this.txt_custpassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_custpassword.Location = new System.Drawing.Point(581, 153);
            this.txt_custpassword.Name = "txt_custpassword";
            this.txt_custpassword.Size = new System.Drawing.Size(147, 29);
            this.txt_custpassword.TabIndex = 44;
            // 
            // lbl_pass
            // 
            this.lbl_pass.AutoSize = true;
            this.lbl_pass.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_pass.Location = new System.Drawing.Point(382, 158);
            this.lbl_pass.Name = "lbl_pass";
            this.lbl_pass.Size = new System.Drawing.Size(175, 24);
            this.lbl_pass.TabIndex = 43;
            this.lbl_pass.Text = "customer Password";
            // 
            // rdb_male
            // 
            this.rdb_male.AutoSize = true;
            this.rdb_male.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdb_male.Location = new System.Drawing.Point(579, 256);
            this.rdb_male.Name = "rdb_male";
            this.rdb_male.Size = new System.Drawing.Size(61, 24);
            this.rdb_male.TabIndex = 45;
            this.rdb_male.TabStop = true;
            this.rdb_male.Text = "Male";
            this.rdb_male.UseVisualStyleBackColor = true;
            // 
            // rdb_female
            // 
            this.rdb_female.AutoSize = true;
            this.rdb_female.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdb_female.Location = new System.Drawing.Point(650, 256);
            this.rdb_female.Name = "rdb_female";
            this.rdb_female.Size = new System.Drawing.Size(80, 24);
            this.rdb_female.TabIndex = 46;
            this.rdb_female.TabStop = true;
            this.rdb_female.Text = "Female";
            this.rdb_female.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.RosyBrown;
            this.ClientSize = new System.Drawing.Size(768, 504);
            this.Controls.Add(this.rdb_female);
            this.Controls.Add(this.rdb_male);
            this.Controls.Add(this.txt_custpassword);
            this.Controls.Add(this.lbl_pass);
            this.Controls.Add(this.lbl_newuser);
            this.Controls.Add(this.lbl_log);
            this.Controls.Add(this.lbl_gender);
            this.Controls.Add(this.txt_email);
            this.Controls.Add(this.lbl_email);
            this.Controls.Add(this.txt_mobile);
            this.Controls.Add(this.lbl_mobile);
            this.Controls.Add(this.lbl_custid);
            this.Controls.Add(this.txt_custname);
            this.Controls.Add(this.lbl_name);
            this.Controls.Add(this.lbl_loginstatus);
            this.Controls.Add(this.btn_newuser);
            this.Controls.Add(this.btn_login);
            this.Controls.Add(this.txt_password);
            this.Controls.Add(this.txt_login);
            this.Controls.Add(this.lbl_password);
            this.Controls.Add(this.lbl_login);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_loginstatus;
        private System.Windows.Forms.Button btn_newuser;
        private System.Windows.Forms.Button btn_login;
        private System.Windows.Forms.TextBox txt_password;
        private System.Windows.Forms.TextBox txt_login;
        private System.Windows.Forms.Label lbl_password;
        private System.Windows.Forms.Label lbl_login;
        private System.Windows.Forms.TextBox txt_email;
        private System.Windows.Forms.Label lbl_email;
        private System.Windows.Forms.TextBox txt_mobile;
        private System.Windows.Forms.Label lbl_mobile;
        private System.Windows.Forms.Label lbl_custid;
        private System.Windows.Forms.TextBox txt_custname;
        private System.Windows.Forms.Label lbl_name;
        private System.Windows.Forms.Label lbl_gender;
        private System.Windows.Forms.Label lbl_log;
        private System.Windows.Forms.Label lbl_newuser;
        private System.Windows.Forms.TextBox txt_custpassword;
        private System.Windows.Forms.Label lbl_pass;
        private System.Windows.Forms.RadioButton rdb_male;
        private System.Windows.Forms.RadioButton rdb_female;
    }
}

